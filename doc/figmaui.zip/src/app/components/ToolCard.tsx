import { Link } from "react-router";
import { LucideIcon } from "lucide-react";

interface ToolCardProps {
  to: string;
  icon: LucideIcon;
  name: string;
  description: string;
  badge?: string;
}

export function ToolCard({ to, icon: Icon, name, description, badge }: ToolCardProps) {
  return (
    <Link
      to={to}
      className="block rounded-[8px] transition-colors duration-100 group"
      style={{
        background: "var(--tk-surface)",
        border: "1px solid var(--tk-border)",
        padding: "24px",
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLElement).style.borderColor = "var(--tk-border-strong)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLElement).style.borderColor = "var(--tk-border)";
      }}
    >
      <div className="flex items-start justify-between gap-2 mb-3">
        <Icon size={24} className="text-[var(--tk-text-secondary)] mt-0.5 shrink-0" />
        {badge && (
          <span
            className="text-[12px] text-[var(--tk-text-tertiary)]"
            style={{
              background: "var(--tk-surface-alt)",
              border: "1px solid var(--tk-border)",
              borderRadius: "4px",
              padding: "0 8px",
              height: "20px",
              display: "inline-flex",
              alignItems: "center",
            }}
          >
            {badge}
          </span>
        )}
      </div>
      <h3 className="text-[var(--tk-text-primary)] mb-1" style={{ fontSize: "1.0625rem", fontWeight: 600 }}>
        {name}
      </h3>
      <p className="text-[14px] text-[var(--tk-text-secondary)] leading-relaxed">{description}</p>
    </Link>
  );
}
