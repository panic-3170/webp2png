interface AdSlotProps {
  width?: number;
  height?: number;
  label?: string;
}

export function AdSlot({ width = 728, height = 90, label = "Ad placeholder" }: AdSlotProps) {
  return (
    <div
      className="rounded-[8px] overflow-hidden"
      style={{
        background: "var(--tk-surface-alt)",
        border: "1px dashed var(--tk-border)",
        padding: "8px",
      }}
    >
      <div className="text-[11px] text-[var(--tk-text-tertiary)] mb-1">Sponsored</div>
      <div
        className="flex items-center justify-center rounded-[4px]"
        style={{
          width: "100%",
          maxWidth: `${width}px`,
          height: `${height}px`,
          margin: "0 auto",
          background: "var(--tk-surface-alt)",
        }}
      >
        <span className="text-xs text-[var(--tk-text-tertiary)]">{label}</span>
      </div>
    </div>
  );
}
