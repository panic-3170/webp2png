import { useRef, useState } from "react";
import { Upload } from "lucide-react";

interface DropzoneProps {
  onFile: (file: File) => void;
  processing: boolean;
  accept?: string;
  maxSizeMB?: number;
  label?: string;
  hint?: string;
}

export function Dropzone({
  onFile,
  processing,
  accept = ".webp,image/webp",
  maxSizeMB = 20,
  label = "Drop WebP here",
  hint = "or click to select",
}: DropzoneProps) {
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => {
    if (file.size > maxSizeMB * 1024 * 1024) return;
    onFile(file);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  const onInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
    e.target.value = "";
  };

  const borderColor = dragOver ? "var(--tk-accent)" : "var(--tk-border-strong)";
  const bg = dragOver ? "var(--tk-surface-alt)" : "var(--tk-surface)";

  return (
    <div
      role="button"
      tabIndex={0}
      aria-label="File drop zone"
      className="rounded-[8px] flex flex-col items-center justify-center text-center transition-colors duration-100 cursor-pointer min-h-[280px] lg:min-h-[320px] select-none"
      style={{
        border: `2px dashed ${borderColor}`,
        background: bg,
        padding: "48px 24px",
        opacity: processing ? 0.6 : 1,
        pointerEvents: processing ? "none" : "auto",
      }}
      onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
      onDragLeave={() => setDragOver(false)}
      onDrop={onDrop}
      onClick={() => inputRef.current?.click()}
      onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") inputRef.current?.click(); }}
    >
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        className="sr-only"
        onChange={onInputChange}
        aria-hidden="true"
      />

      {processing ? (
        <div className="flex flex-col items-center gap-3">
          <div
            className="w-6 h-6 rounded-full border-2 border-transparent animate-spin"
            style={{ borderTopColor: "var(--tk-text-secondary)" }}
          />
          <span className="text-sm text-[var(--tk-text-secondary)]">Converting...</span>
        </div>
      ) : (
        <>
          <Upload size={28} className="mb-4 text-[var(--tk-text-tertiary)]" />
          <p className="text-[var(--tk-text-primary)] mb-1" style={{ fontWeight: 500 }}>
            {label}
          </p>
          <p className="text-sm text-[var(--tk-text-secondary)]">{hint}</p>
          <p className="text-xs text-[var(--tk-text-tertiary)] mt-3">
            Max {maxSizeMB}MB · No upload · 100% local
          </p>
        </>
      )}
    </div>
  );
}
