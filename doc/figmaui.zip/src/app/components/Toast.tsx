import { useEffect } from "react";
import { X, AlertCircle, CheckCircle } from "lucide-react";

export interface ToastMessage {
  id: string;
  message: string;
  type: "error" | "success";
}

interface ToastProps {
  toast: ToastMessage | null;
  onDismiss: () => void;
}

export function Toast({ toast, onDismiss }: ToastProps) {
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(onDismiss, 4000);
    return () => clearTimeout(timer);
  }, [toast, onDismiss]);

  if (!toast) return null;

  const isError = toast.type === "error";

  return (
    <div
      role="alert"
      aria-live="polite"
      className="fixed top-4 left-1/2 -translate-x-1/2 z-50 max-w-sm w-[calc(100%-2rem)] rounded-[6px] flex items-start gap-3 px-4 py-3 transition-opacity duration-150"
      style={{
        background: "var(--tk-surface)",
        border: `1px solid ${isError ? "var(--tk-danger)" : "var(--tk-success)"}`,
        borderLeft: `4px solid ${isError ? "var(--tk-danger)" : "var(--tk-success)"}`,
        boxShadow: "0 1px 2px 0 rgba(0,0,0,0.05)",
      }}
    >
      {isError ? (
        <AlertCircle size={16} className="shrink-0 mt-0.5" style={{ color: "var(--tk-danger)" }} />
      ) : (
        <CheckCircle size={16} className="shrink-0 mt-0.5" style={{ color: "var(--tk-success)" }} />
      )}
      <span className="text-sm text-[var(--tk-text-primary)] flex-1">{toast.message}</span>
      <button
        onClick={onDismiss}
        aria-label="Dismiss"
        className="text-[var(--tk-text-tertiary)] hover:text-[var(--tk-text-primary)] transition-colors duration-100 shrink-0"
      >
        <X size={14} />
      </button>
    </div>
  );
}
