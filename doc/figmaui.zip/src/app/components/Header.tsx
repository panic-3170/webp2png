import { useState } from "react";
import { Link, useLocation } from "react-router";
import { Github, Twitter, Mail, Menu, X } from "lucide-react";

export function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { to: "/", label: "Home" },
    { to: "/tools", label: "Tools" },
    { to: "/about", label: "About" },
  ];

  return (
    <header
      style={{ height: "64px", borderBottom: "1px solid var(--tk-border)" }}
      className="bg-[var(--tk-surface)] relative z-10"
    >
      <div className="max-w-[1100px] mx-auto h-full px-4 lg:px-6 flex items-center justify-between">
        <Link
          to="/"
          className="text-[var(--tk-text-primary)] hover:opacity-80 transition-opacity duration-100"
          style={{ fontWeight: 700, fontSize: "1.125rem", letterSpacing: "-0.02em" }}
        >
          ToolKit<span className="opacity-40">.run</span>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-6">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className="text-sm text-[var(--tk-text-secondary)] hover:text-[var(--tk-text-primary)] transition-colors duration-100"
              style={
                location.pathname === link.to
                  ? { color: "var(--tk-text-primary)", fontWeight: 500 }
                  : {}
              }
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Desktop social icons */}
        <div className="hidden md:flex items-center gap-3">
          <a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="GitHub"
            className="text-[var(--tk-text-tertiary)] hover:text-[var(--tk-text-primary)] transition-colors duration-100"
          >
            <Github size={20} />
          </a>
          <a
            href="https://twitter.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Twitter"
            className="text-[var(--tk-text-tertiary)] hover:text-[var(--tk-text-primary)] transition-colors duration-100"
          >
            <Twitter size={20} />
          </a>
          <Link
            to="/contact"
            aria-label="Contact"
            className="text-[var(--tk-text-tertiary)] hover:text-[var(--tk-text-primary)] transition-colors duration-100"
          >
            <Mail size={20} />
          </Link>
        </div>

        {/* Mobile hamburger */}
        <button
          className="md:hidden text-[var(--tk-text-primary)] p-2 -mr-2"
          aria-label={menuOpen ? "Close menu" : "Open menu"}
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile drawer */}
      {menuOpen && (
        <div
          className="md:hidden absolute top-full left-0 right-0 bg-[var(--tk-surface)] border-b"
          style={{ borderColor: "var(--tk-border)" }}
        >
          <nav className="max-w-[1100px] mx-auto px-4 py-4 flex flex-col gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setMenuOpen(false)}
                className="py-2 text-sm text-[var(--tk-text-secondary)] hover:text-[var(--tk-text-primary)] transition-colors duration-100"
              >
                {link.label}
              </Link>
            ))}
            <div className="flex items-center gap-4 pt-2 mt-2" style={{ borderTop: "1px solid var(--tk-border)" }}>
              <a href="https://github.com" target="_blank" rel="noopener noreferrer" aria-label="GitHub" className="text-[var(--tk-text-tertiary)]">
                <Github size={18} />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" aria-label="Twitter" className="text-[var(--tk-text-tertiary)]">
                <Twitter size={18} />
              </a>
              <Link to="/contact" aria-label="Contact" className="text-[var(--tk-text-tertiary)]" onClick={() => setMenuOpen(false)}>
                <Mail size={18} />
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
