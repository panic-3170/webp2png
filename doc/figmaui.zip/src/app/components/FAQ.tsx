interface FAQItem {
  q: string;
  a: string;
}

interface FAQProps {
  items: FAQItem[];
}

export function FAQ({ items }: FAQProps) {
  return (
    <section>
      <h2 className="text-[var(--tk-text-primary)] mb-8" style={{ fontSize: "clamp(1.5rem, 3vw, 2rem)", fontWeight: 600, letterSpacing: "-0.01em" }}>
        Frequently Asked Questions
      </h2>
      <div className="flex flex-col">
        {items.map((item, i) => (
          <div
            key={i}
            className="py-5"
            style={i < items.length - 1 ? { borderBottom: "1px solid var(--tk-border)" } : {}}
          >
            <p className="text-[var(--tk-text-primary)] mb-2" style={{ fontSize: "1rem", fontWeight: 600 }}>
              {item.q}
            </p>
            <p className="text-[14px] text-[var(--tk-text-secondary)]" style={{ lineHeight: 1.7 }}>
              {item.a}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
