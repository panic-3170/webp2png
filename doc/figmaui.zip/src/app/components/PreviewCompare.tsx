interface FileInfo {
  url: string;
  name: string;
  width: number;
  height: number;
  sizeKB: number;
  label: string;
}

interface PreviewCompareProps {
  original: FileInfo;
  converted: FileInfo;
}

function CheckerBackground({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="relative w-full h-[240px] rounded-[6px] overflow-hidden"
      style={{
        backgroundImage: `
          linear-gradient(45deg, var(--tk-surface-alt) 25%, transparent 25%),
          linear-gradient(-45deg, var(--tk-surface-alt) 25%, transparent 25%),
          linear-gradient(45deg, transparent 75%, var(--tk-surface-alt) 75%),
          linear-gradient(-45deg, transparent 75%, var(--tk-surface-alt) 75%)
        `,
        backgroundSize: "16px 16px",
        backgroundPosition: "0 0, 0 8px, 8px -8px, -8px 0px",
        backgroundColor: "var(--tk-surface)",
      }}
    >
      {children}
    </div>
  );
}

function PreviewCard({ info }: { info: FileInfo }) {
  return (
    <div className="flex-1 min-w-0">
      <CheckerBackground>
        <img
          src={info.url}
          alt={info.label === "Original" ? "Original WebP image" : "Converted PNG image"}
          className="w-full h-full object-contain"
        />
      </CheckerBackground>
      <div className="mt-3 text-left">
        <p className="text-[14px] text-[var(--tk-text-primary)]" style={{ fontWeight: 500 }}>
          {info.label}
        </p>
        <p className="text-[13px] text-[var(--tk-text-secondary)] mt-0.5">
          {info.width} × {info.height} · {info.sizeKB} KB
        </p>
      </div>
    </div>
  );
}

export function PreviewCompare({ original, converted }: PreviewCompareProps) {
  return (
    <div className="flex flex-col md:flex-row gap-4">
      <PreviewCard info={original} />
      <PreviewCard info={converted} />
    </div>
  );
}
