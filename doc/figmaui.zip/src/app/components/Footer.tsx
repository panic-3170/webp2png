import { Link } from "react-router";

export function Footer() {
  return (
    <footer
      className="mt-auto"
      style={{ borderTop: "1px solid var(--tk-border)" }}
    >
      <div className="max-w-[1100px] mx-auto px-4 lg:px-6 py-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-[13px] text-[var(--tk-text-tertiary)]">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <span>© 2026 ToolKit.run</span>
            <span className="hidden sm:inline opacity-40">·</span>
            <Link to="/privacy" className="hover:text-[var(--tk-text-secondary)] transition-colors duration-100">Privacy</Link>
            <span className="opacity-40">·</span>
            <Link to="/about" className="hover:text-[var(--tk-text-secondary)] transition-colors duration-100">About</Link>
            <span className="opacity-40">·</span>
            <Link to="/contact" className="hover:text-[var(--tk-text-secondary)] transition-colors duration-100">Contact</Link>
          </div>
          <span className="text-[var(--tk-text-tertiary)]">Files never leave your device.</span>
        </div>
      </div>
    </footer>
  );
}
