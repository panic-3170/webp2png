import { useEffect, useState } from "react";
import { ArrowUp } from "lucide-react";

export function BackToTop() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 600);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (!visible) return null;

  return (
    <button
      onClick={scrollToTop}
      aria-label="Back to top"
      className="hidden lg:flex fixed bottom-6 right-6 w-12 h-12 rounded-full items-center justify-center transition-opacity duration-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--tk-focus-ring)] focus-visible:ring-offset-2"
      style={{
        background: "var(--tk-accent)",
        color: "var(--tk-accent-fg)",
      }}
    >
      <ArrowUp size={18} />
    </button>
  );
}
