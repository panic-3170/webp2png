import { BrowserRouter, Routes, Route } from "react-router";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import { BackToTop } from "./components/BackToTop";
import { HomePage } from "./pages/HomePage";
import { WebpToPngPage } from "./pages/WebpToPngPage";
import { StaticPage } from "./pages/StaticPage";
import { NotFoundPage } from "./pages/NotFoundPage";

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col" style={{ background: "var(--tk-bg)" }}>
      <Header />
      <main className="flex-1">{children}</main>
      <Footer />
      <BackToTop />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/tools" element={<HomePage />} />
          <Route path="/webp-to-png" element={<WebpToPngPage />} />
          <Route
            path="/privacy"
            element={
              <StaticPage title="Privacy Policy">
                <p className="mb-4">
                  ToolKit.run is a browser-based tool suite. All file processing happens entirely on your device. We never receive, store, or transmit your files to any server.
                </p>
                <p className="mb-4">
                  We use minimal, privacy-respecting analytics to understand which tools are used. No personal data is collected.
                </p>
                <p className="mb-4">
                  This site may display contextual advertisements served by third-party ad networks. These networks may use cookies to serve ads based on your browsing history.
                </p>
                <p>
                  If you have questions, please <a href="/contact" className="underline hover:text-[var(--tk-text-primary)] transition-colors duration-100">contact us</a>.
                </p>
              </StaticPage>
            }
          />
          <Route
            path="/about"
            element={
              <StaticPage title="About ToolKit">
                <p className="mb-4">
                  ToolKit.run is a collection of simple, fast, privacy-first browser tools. No accounts, no uploads, no tracking.
                </p>
                <p className="mb-4">
                  Every tool processes files directly in your browser using modern Web APIs — Canvas, WebAssembly, FileReader. Your files stay on your device.
                </p>
                <p className="mb-4">
                  The project is maintained by a small team passionate about building useful software that respects users. It's free, ad-supported, and open source.
                </p>
                <p>
                  Built with React, Tailwind CSS, and the Web Platform.
                </p>
              </StaticPage>
            }
          />
          <Route
            path="/contact"
            element={
              <StaticPage title="Contact">
                <p className="mb-4">
                  Have a question, found a bug, or want to suggest a new tool? We'd love to hear from you.
                </p>
                <p className="mb-4">
                  Email us at:{" "}
                  <a
                    href="mailto:hello@toolkit.run"
                    className="underline hover:text-[var(--tk-text-primary)] transition-colors duration-100"
                  >
                    hello@toolkit.run
                  </a>
                </p>
                <p className="text-[var(--tk-text-tertiary)] text-sm">
                  We try to respond within 24–48 hours on business days.
                </p>
              </StaticPage>
            }
          />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}
