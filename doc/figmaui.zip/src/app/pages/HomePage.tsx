import { FileImage, FileType, Image, Code } from "lucide-react";
import { ToolCard } from "../components/ToolCard";

const tools = [
  {
    to: "/webp-to-png",
    icon: FileImage,
    name: "WebP → PNG",
    description: "Convert WebP images to transparent PNG. 100% local, no upload.",
    badge: "Free",
  },
  {
    to: "/webp-to-jpg",
    icon: FileType,
    name: "WebP → JPG",
    description: "Convert WebP to JPEG with quality control. Instant, browser-based.",
    badge: "Soon",
  },
  {
    to: "/heic-to-jpg",
    icon: Image,
    name: "HEIC → JPG",
    description: "Turn iPhone HEIC photos into universal JPEG files. No software needed.",
    badge: "Soon",
  },
  {
    to: "/svg-to-png",
    icon: Code,
    name: "SVG → PNG",
    description: "Rasterize SVG vectors to PNG at any resolution. Client-side only.",
    badge: "Soon",
  },
];

const valueProps = [
  "Files never leave your device.",
  "No signup, no email, no tracking.",
  "Works on any modern browser.",
  "Open source. Free forever.",
];

export function HomePage() {
  return (
    <div className="max-w-[1100px] mx-auto px-4 lg:px-6 py-16 lg:py-24">
      {/* Hero */}
      <div className="mb-16">
        <h1
          className="text-[var(--tk-text-primary)] mb-4"
          style={{ fontSize: "clamp(2rem, 4vw, 3rem)", fontWeight: 700, letterSpacing: "-0.02em", lineHeight: 1.15 }}
        >
          Free Online Tools
        </h1>
        <p className="text-[var(--tk-text-secondary)] max-w-xl" style={{ fontSize: "1.125rem", lineHeight: 1.6 }}>
          Simple, private, browser-based. No uploads, no signup.
        </p>
      </div>

      {/* Tool grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-24">
        {tools.map((tool) => (
          <ToolCard key={tool.to} {...tool} />
        ))}
      </div>

      {/* Value props */}
      <div style={{ borderTop: "1px solid var(--tk-border)", paddingTop: "64px" }}>
        <h2
          className="text-[var(--tk-text-secondary)] mb-8 uppercase tracking-widest"
          style={{ fontSize: "0.75rem", fontWeight: 500 }}
        >
          Why ToolKit?
        </h2>
        <ul className="flex flex-col gap-4">
          {valueProps.map((prop) => (
            <li key={prop} className="flex items-center gap-3">
              <span style={{ color: "var(--tk-success)", fontWeight: 600, fontSize: "1rem" }}>✓</span>
              <span className="text-[var(--tk-text-primary)]" style={{ fontSize: "1.0625rem" }}>
                {prop}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
