import { Link } from "react-router";

export function NotFoundPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] px-4 text-center">
      <svg
        width="120"
        height="60"
        viewBox="0 0 120 60"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="mb-8"
        aria-hidden="true"
      >
        <text
          x="50%"
          y="50"
          textAnchor="middle"
          fontSize="52"
          fontWeight="700"
          fontFamily="Inter, sans-serif"
          fill="var(--tk-border-strong)"
          letterSpacing="-2"
        >
          404
        </text>
      </svg>
      <p className="text-[var(--tk-text-secondary)] mb-8" style={{ fontSize: "1.125rem" }}>
        Page not found.
      </p>
      <Link
        to="/"
        className="h-10 px-4 rounded-[6px] inline-flex items-center transition-opacity duration-100 hover:opacity-90 text-sm"
        style={{
          background: "var(--tk-accent)",
          color: "var(--tk-accent-fg)",
          fontWeight: 500,
        }}
      >
        Back to home
      </Link>
    </div>
  );
}
