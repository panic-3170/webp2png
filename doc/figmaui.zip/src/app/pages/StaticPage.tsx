interface StaticPageProps {
  title: string;
  children: React.ReactNode;
}

export function StaticPage({ title, children }: StaticPageProps) {
  return (
    <div className="max-w-[720px] mx-auto px-4 lg:px-6 py-16 lg:py-24">
      <h1
        className="text-[var(--tk-text-primary)] mb-10"
        style={{ fontSize: "clamp(2rem, 4vw, 3rem)", fontWeight: 700, letterSpacing: "-0.02em", lineHeight: 1.15 }}
      >
        {title}
      </h1>
      <div
        className="text-[var(--tk-text-secondary)]"
        style={{ fontSize: "1rem", lineHeight: 1.7 }}
      >
        {children}
      </div>
    </div>
  );
}
