import { useState, useCallback, useRef } from "react";
import { FileImage, Code, Image as ImageIcon } from "lucide-react";
import { Dropzone } from "../components/Dropzone";
import { PreviewCompare } from "../components/PreviewCompare";
import { AdSlot } from "../components/AdSlot";
import { FAQ } from "../components/FAQ";
import { ToolCard } from "../components/ToolCard";
import { Toast, ToastMessage } from "../components/Toast";

interface ConvertedResult {
  originalUrl: string;
  originalName: string;
  originalWidth: number;
  originalHeight: number;
  originalSizeKB: number;
  pngUrl: string;
  pngSizeKB: number;
  pngBlob: Blob;
}

const faqItems = [
  {
    q: "Is this tool really free?",
    a: "Yes. No signup, no payment, no catch. ToolKit.run is supported by non-intrusive ads.",
  },
  {
    q: "Do you upload my files?",
    a: "No. All processing happens entirely in your browser using the Canvas API. Your files never leave your device.",
  },
  {
    q: "Does the PNG support transparency?",
    a: "Yes. WebP images with alpha (transparent) channels are fully preserved in the output PNG.",
  },
  {
    q: "What's the maximum file size?",
    a: "20 MB per file in this version. Larger files may be supported in future updates.",
  },
  {
    q: "Will the PNG be larger than the WebP?",
    a: "Usually yes — PNG is lossless while WebP uses lossy or lossless compression. The tradeoff is maximum compatibility.",
  },
  {
    q: "Does it work on mobile?",
    a: "Yes. The tool works on iOS Safari, Android Chrome, and all modern mobile browsers.",
  },
];

const relatedTools = [
  { to: "/webp-to-jpg", icon: FileImage, name: "WebP → JPG", description: "Convert WebP to JPEG with quality control." },
  { to: "/heic-to-jpg", icon: ImageIcon, name: "HEIC → JPG", description: "Convert iPhone HEIC photos to universal JPEG." },
  { to: "/svg-to-png", icon: Code, name: "SVG → PNG", description: "Rasterize SVG vectors to PNG at any resolution." },
];

export function WebpToPngPage() {
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState<ConvertedResult | null>(null);
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const showToast = (message: string, type: "error" | "success") => {
    setToast({ id: Date.now().toString(), message, type });
  };

  const convertFile = useCallback(async (file: File) => {
    if (!file.type.includes("webp") && !file.name.toLowerCase().endsWith(".webp")) {
      showToast("Please select a WebP file.", "error");
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      showToast("File is too large. Maximum size is 20 MB.", "error");
      return;
    }

    setProcessing(true);
    setResult(null);

    try {
      const originalUrl = URL.createObjectURL(file);

      await new Promise<void>((resolve, reject) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement("canvas");
          canvas.width = img.width;
          canvas.height = img.height;
          const ctx = canvas.getContext("2d")!;
          ctx.drawImage(img, 0, 0);

          canvas.toBlob((blob) => {
            if (!blob) {
              reject(new Error("Conversion failed"));
              return;
            }
            const pngUrl = URL.createObjectURL(blob);
            setResult({
              originalUrl,
              originalName: file.name,
              originalWidth: img.width,
              originalHeight: img.height,
              originalSizeKB: Math.round(file.size / 1024),
              pngUrl,
              pngSizeKB: Math.round(blob.size / 1024),
              pngBlob: blob,
            });
            resolve();
          }, "image/png");
        };
        img.onerror = () => reject(new Error("Failed to load image"));
        img.src = originalUrl;
      });
    } catch {
      showToast("Conversion failed. Please try another file.", "error");
    } finally {
      setProcessing(false);
    }
  }, []);

  const handleDownload = () => {
    if (!result) return;
    const a = document.createElement("a");
    a.href = result.pngUrl;
    a.download = result.originalName.replace(/\.webp$/i, "") + ".png";
    a.click();
  };

  const handleReset = () => {
    if (result) {
      URL.revokeObjectURL(result.originalUrl);
      URL.revokeObjectURL(result.pngUrl);
    }
    setResult(null);
  };

  return (
    <>
      <canvas ref={canvasRef} className="hidden" />
      <Toast toast={toast} onDismiss={() => setToast(null)} />

      <div className="flex gap-8">
        {/* Main content */}
        <div className="flex-1 min-w-0 max-w-[1100px] mx-auto px-4 lg:px-6 py-8 lg:py-16">
          {/* Top ad */}
          <div className="mb-10 hidden sm:block">
            <AdSlot width={728} height={90} />
          </div>
          <div className="mb-8 sm:hidden">
            <AdSlot width={320} height={100} />
          </div>

          {/* Heading */}
          <div className="mb-10">
            <h1
              className="text-[var(--tk-text-primary)] mb-3"
              style={{ fontSize: "clamp(2rem, 4vw, 3rem)", fontWeight: 700, letterSpacing: "-0.02em", lineHeight: 1.15 }}
            >
              WebP to Transparent PNG
            </h1>
            <p className="text-[var(--tk-text-secondary)]" style={{ fontSize: "1rem", lineHeight: 1.6 }}>
              100% local processing. Files never leave your device.
            </p>
          </div>

          {/* Dropzone or Result */}
          {!result ? (
            <Dropzone
              onFile={convertFile}
              processing={processing}
              label="Drop WebP here"
              hint="or click to select"
            />
          ) : (
            <>
              {/* Preview */}
              <PreviewCompare
                original={{
                  url: result.originalUrl,
                  name: result.originalName,
                  width: result.originalWidth,
                  height: result.originalHeight,
                  sizeKB: result.originalSizeKB,
                  label: "Original",
                }}
                converted={{
                  url: result.pngUrl,
                  name: result.originalName.replace(/\.webp$/i, ".png"),
                  width: result.originalWidth,
                  height: result.originalHeight,
                  sizeKB: result.pngSizeKB,
                  label: "PNG (transparent)",
                }}
              />

              {/* Actions */}
              <div className="mt-6 flex flex-col sm:flex-row gap-3">
                <button
                  onClick={handleDownload}
                  className="h-12 px-5 rounded-[6px] transition-opacity duration-100 hover:opacity-90 active:opacity-80 focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--tk-focus-ring)] focus-visible:ring-offset-2 sm:w-auto w-full"
                  style={{
                    background: "var(--tk-accent)",
                    color: "var(--tk-accent-fg)",
                    fontWeight: 500,
                    fontSize: "1rem",
                  }}
                >
                  Download PNG
                </button>
                <button
                  onClick={handleReset}
                  className="h-12 px-5 rounded-[6px] transition-colors duration-100 hover:border-[var(--tk-border-strong)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--tk-focus-ring)] focus-visible:ring-offset-2 sm:w-auto w-full"
                  style={{
                    background: "var(--tk-surface)",
                    border: "1px solid var(--tk-border)",
                    color: "var(--tk-text-primary)",
                    fontWeight: 500,
                    fontSize: "1rem",
                  }}
                >
                  Convert Another
                </button>
              </div>

              {/* Post-conversion ad */}
              <div className="mt-10">
                <AdSlot width={336} height={280} label="336×280 Ad" />
              </div>
            </>
          )}

          {/* FAQ */}
          <div className="mt-16 lg:mt-24" style={{ borderTop: "1px solid var(--tk-border)", paddingTop: "64px" }}>
            <FAQ items={faqItems} />
          </div>

          {/* Related tools */}
          <div className="mt-16 lg:mt-24">
            <h2
              className="text-[var(--tk-text-primary)] mb-6"
              style={{ fontSize: "clamp(1.5rem, 3vw, 2rem)", fontWeight: 600, letterSpacing: "-0.01em" }}
            >
              Related Tools
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {relatedTools.map((tool) => (
                <ToolCard key={tool.to} {...tool} />
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar sticky ad (desktop only) */}
        <div className="hidden xl:block w-[320px] shrink-0 pt-8 lg:pt-16">
          <div className="sticky top-6">
            <AdSlot width={300} height={600} label="300×600 Ad" />
          </div>
        </div>
      </div>
    </>
  );
}
